export const environment = {
  production: true,
  apiBase: '/oktobeermutfest/api',
};
