export type ItemKey = "500" | "250" | "bottle";
